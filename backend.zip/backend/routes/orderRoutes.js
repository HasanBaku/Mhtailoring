const express = require('express');
const express = require('express');
const router = express.Router(); // ✅ CORRECT
const { createOrder, getOrders } = require('../controllers/orderController');

// Make sure both handlers are real functions
router.post('/', createOrder);
router.get('/', getOrders);

module.exports = router;
