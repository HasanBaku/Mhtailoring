// backend/routes/invoiceRoutes.js

const express = require('express');
const express = require('express');
const router = express.Router(); // ✅ CORRECT
const { createInvoice, getInvoices } = require('../controllers/invoiceController');

router.post('/', createInvoice);
router.get('/', getInvoices);

module.exports = router;
