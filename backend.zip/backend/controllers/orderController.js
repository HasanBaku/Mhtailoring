const createOrder = (req, res) => {
  // logic here
  res.json({ message: 'Order created' });
};

const getOrders = (req, res) => {
  // logic here
  res.json({ orders: [] });
};

module.exports = { createOrder, getOrders };
