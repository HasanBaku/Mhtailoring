// backend/controllers/invoiceController.js

const createInvoice = (req, res) => {
  // Replace with real logic later
  res.status(201).json({ message: 'Invoice created' });
};

const getInvoices = (req, res) => {
  // Replace with real logic later
  res.status(200).json({ invoices: [] });
};

module.exports = { createInvoice, getInvoices };
